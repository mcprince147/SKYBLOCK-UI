<?php

namespace SkyBlock\command;

use SkyBlock\Utils;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\level\Position;
use pocketmine\Player;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use SkyBlock\invitation\Invitation;
use SkyBlock\island\Island;
use SkyBlock\SkyBlock;
use SkyBlock\reset\Reset;

class SkyBlockCommand extends Command {

    /** @var SkyBlock */
    private $plugin;

    /**
     * SkyBlockCommand constructor.
     *
     * @param SkyBlock $plugin
     */
    public function __construct(SkyBlock $plugin) {
        $this->plugin = $plugin;
        parent::__construct("ada", "SkyBlock!", "Kullanım: /ada", ["sb"]);
    }

    public function sendMessage(Player $sender, $message) {
        $sender->sendMessage("§7» " .$message);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) {
        if($sender instanceof Player) {
            if(isset($args[0])) {
                switch($args[0]) {
                    case "isinlan":
 $this->plugin->getSkyBlockManager()->getPlayerConfig($sender);
                        $config = $this->plugin->getSkyBlockManager()->getPlayerConfig($sender);
                        if(empty($config->get("island"))) {
                            $this->sendMessage($sender, "§cBir ada'ya sahip değilsin!");
                        }
                        else {
                            $island = $this->plugin->getIslandManager()->getOnlineIsland($config->get("island"));
                            if($island instanceof Island) {
                                $island->addPlayer($sender);
                                $sender->teleport(new Position(15, 7, 10, $this->plugin->getServer()->getLevelByName($island->getIdentifier())));
                                $this->sendMessage($sender, "§aAda'ya ışınlanıyorsun");
                            }
                            else {
                                $this->sendMessage($sender, "§cBir ada'ya sahip değilsin!");
                            }
                        }
                        break;
                    case "olustur":
                        $config = $this->plugin->getSkyBlockManager()->getPlayerConfig($sender);
                        if(empty($config->get("island"))) {
                            $reset = $this->plugin->getResetHandler()->getResetTimer($sender);
                            if($reset instanceof Reset) {
                                $minutes = Utils::printSeconds($reset->getTime());
                                $this->sendMessage($sender, "§a{$minutes} §cdakika içinde yeni bir ada oluşturabileceksiniz!");
                            }
                            else {
                                $skyBlockManager = $this->plugin->getSkyBlockGeneratorManager();
                                if(isset($args[1])) {
                                    if($skyBlockManager->isGenerator($args[1])) {
                                        $this->plugin->getSkyBlockManager()->generateIsland($sender, $args[1]);
                                        $this->sendMessage($sender, "§aAda oluşturuldu!");
                                    }
                                    else {
                                        $this->sendMessage($sender, "§cAda oluşturulamadı!");
                                    }
                                }
                                else {
                                    $this->plugin->getSkyBlockManager()->generateIsland($sender, "basic");
                                    $this->sendMessage($sender, "§aBaşarılı bir ada oluşturdunuz!");
                                }
                            }
                        }
                        else {
                            $this->sendMessage($sender, "§cZaten bir skyblock adasına sahipsin!");
                        }
                        break;
                    case "ev":
                        $config = $this->plugin->getSkyBlockManager()->getPlayerConfig($sender);
                        if(empty($config->get("island"))) {
                            $this->sendMessage($sender, "§cBir ada'ya sahip değilsin");
                        }
                        else {
                            $island = $this->plugin->getIslandManager()->getOnlineIsland($config->get("island"));
                            if($island instanceof Island) {
                                $home = $island->getHomePosition();
                                if($home instanceof Position) {
                                    $sender->teleport($home);
                                    $this->sendMessage($sender, "§aAda evine ışınlandın.");
                                }
                                else {
                                    $this->sendMessage($sender, "§cAdanın bir ev yeri yok!");
                                }
                            }
                            else {
                                $this->sendMessage($sender, "§cBir ada'ya sahip değilsin!");
                            }
                        }
                        break;
                    case "evayarla":
                        $config = $this->plugin->getSkyBlockManager()->getPlayerConfig($sender);
                        if(empty($config->get("island"))) {
                            $this->sendMessage($sender, "§cBir ada'ya sahip değilsin");
                        }
                        else {
                            $island = $this->plugin->getIslandManager()->getOnlineIsland($config->get("island"));
                            if($island instanceof Island) {
                                if($island->getOwnerName() == strtolower($sender->getName())) {
                                    if($sender->getLevel()->getName() == $config->get("island")) {
                                        $island->setHomePosition($sender->getPosition());
                                        $this->sendMessage($sender, "§aAdada başarılı bir şekilde ev ayarladın!");
                                    }
                                    else {
                                        $this->sendMessage($sender, "§cEvini ayarlamak için adada olmalısın!");
                                    }
                                }
                                else {
                                    $this->sendMessage($sender, "§cBunu yapmak için ada sahibi olmalısın!");
                                }
                            }
                            else {
                                $this->sendMessage($sender, "§cBir ada'ya sahip değilsin!");
                            }
                        }
                        break;
                    case "tekmele":
                    case "kov":
                        $config = $this->plugin->getSkyBlockManager()->getPlayerConfig($sender);
                        if(empty($config->get("island"))) {
                            $this->sendMessage($sender, "§cBir ada'ya sahip değilsin");
                        }
                        else {
                            $island = $this->plugin->getIslandManager()->getOnlineIsland($config->get("island"));
                            if($island instanceof Island) {
                                if($island->getOwnerName() == strtolower($sender->getName())) {
                                    if(isset($args[1])) {
                                        $player = $this->plugin->getServer()->getPlayer($args[1]);
                                        if($player instanceof Player and $player->isOnline()) {
                                            if($player->getLevel()->getName() == $island->getIdentifier()) {
                                                $player->teleport($this->plugin->getServer()->getDefaultLevel()->getSafeSpawn());
                                                $this->sendMessage($sender, "§e{$player->getName()} §aadadan tekmelendi!");
                                            }
                                            else {
                                                $this->sendMessage($sender, "§cOyuncu senin adanın içinde değil!");
                                            }
                                        }
                                        else {
                                            $this->sendMessage($sender, "§cBu geçerli bir oyuncu değil!");
                                        }
                                    }
                                    else {
                                        $this->sendMessage($sender, "§fKullanım: §a/ada tekmele <isim>");
                                    }
                                }
                                else {
                                    $this->sendMessage($sender, "§cAda sahibi olmalısın!");
                                }
                            }
                            else {
                                $this->sendMessage($sender, "§cBir ada'ya sahip değilsin");
                            }
                        }
                        break;
                    case "kilit":
                        $config = $this->plugin->getSkyBlockManager()->getPlayerConfig($sender);
                        if(empty($config->get("island"))) {
                            $this->sendMessage($sender, "§cBir ada'ya sahip değilsin");
                        }
                        else {
                            $island = $this->plugin->getIslandManager()->getOnlineIsland($config->get("island"));
                            if($island instanceof Island) {
                                if($island->getOwnerName() == strtolower($sender->getName())) {
                                    $island->setLocked(!$island->isLocked());
                                    $locked = ($island->isLocked()) ? "klitli" : "kilitsiz";
                                    $this->sendMessage($sender, "§aŞu an ki durum:§e {$locked}!");
                                }
                                else {
                                    $this->sendMessage($sender, "§cBunu yapmak için ada sahibi olmalısın!");
                                }
                            }
                            else {
                                $this->sendMessage($sender, "§cBir ada'ya sahip değilsin");
                            }
                        }
                        break;
                    case "ortakekle":
                        $config = $this->plugin->getSkyBlockManager()->getPlayerConfig($sender);
                        if(empty($config->get("island"))) {
                            $this->sendMessage($sender, "§cBir ada'ya sahip değilsin");
                        }
                        else {
                            $island = $this->plugin->getIslandManager()->getOnlineIsland($config->get("island"));
                            if($island instanceof Island) {
                                if($island->getOwnerName() == strtolower($sender->getName())) {
                                    if(isset($args[1])) {
                                        $player = $this->plugin->getServer()->getPlayer($args[1]);
                                        if($player instanceof Player and $player->isOnline()) {
                                            $config = $this->plugin->getSkyBlockManager()->getPlayerConfig($player);
                                            if(empty($config->get("island"))) {
                                                $this->plugin->getInvitationHandler()->addInvitation($sender, $player, $island);
                                                $this->sendMessage($sender, "§e{$player->getName()}§a oyuncusuna bir davet gönderdin!");
                                                $this->sendMessage($player, "§e{$sender->getName()} §aseni adasına davet etti!\n§6 /ada <kabul/red> {$sender->getName()}");
                                            }
                                            else {
                                                $this->sendMessage($sender, "Bu oyuncu zaten bir adada!");
                                            }
                                        }
                                        else {
                                            $this->sendMessage($sender, "§e{$args[1]}§c geçerli bir oyuncu değil!");
                                        }
                                    }
                                    else {
                                        $this->sendMessage($sender, "§fKullanım: §6/ada davet <oyuncu>");
                                    }
                                }
                                else {
                                    $this->sendMessage($sender, "Bunu yapmak için ada sahibi olmalısın!");
                                }
                            }
                            else {
                                $this->sendMessage($sender, "§cBir ada'ya sahip değilsin!");
                            }
                        }
                        break;
                    case "kabul":
                        if(isset($args[1])) {
                            $config = $this->plugin->getSkyBlockManager()->getPlayerConfig($sender);
                            if(empty($config->get("island"))) {
                                $player = $this->plugin->getServer()->getPlayer($args[1]);
                                if($player instanceof Player and $player->isOnline()) {
                                    $invitation = $this->plugin->getInvitationHandler()->getInvitation($player);
                                    if($invitation instanceof Invitation) {
                                        if($invitation->getSender() === $player) {
                                            $invitation->accept();
                                        }
                                        else {
                                            $this->sendMessage($sender, "§e{$player->getName()} §coyuncusundan davet almadınız!");
                                        }
                                    }
                                    else {
                                        $this->sendMessage($sender, "§e{$player->getName()} §coyuncusundan davet almadınız!");
                                    }
                                }
                                else {
                                    $this->sendMessage($sender, "§e{$args[1]} §cgeçerli bir oyuncu değil!");
                                }
                            }
                            else {
                                $this->sendMessage($sender, "§cBaşka bir adaya katılmak istersen, bir adada olamazsın!");
                            }
                        }
                        else {
                            $this->sendMessage($sender, "§fKullanım: /ada kabul <davet-isim>");
                        }
                        break;
                    case "red":
                        if(isset($args[1])) {
                            $config = $this->plugin->getSkyBlockManager()->getPlayerConfig($sender);
                            if(empty($config->get("island"))) {
                                $player = $this->plugin->getServer()->getPlayer($args[1]);
                                if($player instanceof Player and $player->isOnline()) {
                                    $invitation = $this->plugin->getInvitationHandler()->getInvitation($player);
                                    if($invitation instanceof Invitation) {
                                        if($invitation->getSender() === $player) {
                                            $invitation->deny();
                                        }
                                        else {
                                            $this->sendMessage($sender, "§e{$player->getName()} §coyuncusundan davet almadınız!");
                                        }
                                    }
                                    else {
                                        $this->sendMessage($sender, "§e{$player->getName()} §coyuncusundan davet almadınız!");
                                    }
                                }
                                else {
                                    $this->sendMessage($sender, "§e{$args[1]} §cgeçerli bir oyuncu değil!");
                                }
                            }
                            else {
                                $this->sendMessage($sender, "Başka bir adayı reddetmek istiyorsanız bir adada olamazsınız!");
                            }
                        }
                        else {
                            $this->sendMessage($sender, "§fKullanım: /ada red <davet-isim>");
                        }
                        break;
                    case "ortaklar":
                        $config = $this->plugin->getSkyBlockManager()->getPlayerConfig($sender);
                        if(empty($config->get("island"))) {
                            $this->sendMessage($sender, "§cBu komutu kullanmak için bir adada olmalısın!");
                        }
                        else {
                            $island = $this->plugin->getIslandManager()->getOnlineIsland($config->get("island"));
                            if($island instanceof Island) {
                                $this->sendMessage($sender, "§a-=+=-§6| §eOrtaklar §6|§a-=+=-");
                                $i = 1;
                                foreach($island->getAllMembers() as $member) {
                                    $this->sendMessage($sender, "§a{$i} §6»§a {$member}");
                                    $i++;
                                }
                            }
                            else {
                                $this->sendMessage($sender, "Bu komutu kullanmak için bir adada olmalısınız!");
                            }
                        }
                        break;
                    case "sil":
                        $config = $this->plugin->getSkyBlockManager()->getPlayerConfig($sender);
                        if(empty($config->get("island"))) {
                            $this->sendMessage($sender, "§cAda'yı silmek için bir adada olmalısın!");
                        }
                        else {
                            $island = $this->plugin->getIslandManager()->getOnlineIsland($config->get("island"));
                            if($island instanceof Island) {
                                if($island->getOwnerName() == strtolower($sender->getName())) {
                                    foreach($island->getAllMembers() as $member) {
                                        $memberConfig = new Config($this->plugin->getDataFolder() . "users" . DIRECTORY_SEPARATOR . $member . ".json", Config::JSON);
                                        $memberConfig->set("island", "");
                                        $memberConfig->save();
                                    }
                                    $this->plugin->getIslandManager()->removeIsland($island);
                                    $this->plugin->getResetHandler()->addResetTimer($sender);
                                    $this->sendMessage($sender, "§aAda başarıyla silindi!");
                                }
                                else {
                                    $this->sendMessage($sender, "§cAda'yı silmek için ada sahibi olmalısın!");
                                }
                            }
                            else {
                                $this->sendMessage($sender, "§cAda'yı silmek için bir adada olmalısın!");
                            }
                        }
                        break;
                    case "sjsakflh":
                        $config = $this->plugin->getSkyBlockManager()->getPlayerConfig($sender);
                        if(empty($config->get("island"))) {
                            $this->sendMessage($sender, "You must be in a island to set a new leader!");
                        }
                        else {
                            $island = $this->plugin->getIslandManager()->getOnlineIsland($config->get("island"));
                            if($island instanceof Island) {
                                if($island->getOwnerName() == strtolower($sender->getName())) {
                                    if(isset($args[1])) {
                                        $player = $this->plugin->getServer()->getPlayer($args[1]);
                                        if($player instanceof Player and $player->isOnline()) {
                                            $playerConfig = $this->plugin->getSkyBlockManager()->getPlayerConfig($player);
                                            $playerIsland = $this->plugin->getIslandManager()->getOnlineIsland($playerConfig->get("island"));
                                            if($island === $playerIsland) {
                                                $island->setOwnerName($player->getName());
                                                $island->addPlayer($player);
                                                $island->update();
                                                $this->sendMessage($sender, "You sent the ownership to {$player->getName()}");
                                                $this->sendMessage($player, "You get your island ownership by {$sender->getName()}");
                                            }
                                            else {
                                                $this->sendMessage($sender, "The player should be on your island!");
                                            }
                                        }
                                        else {
                                            $this->sendMessage($sender, "{$args[1]} isn't a valid player!");
                                        }
                                    }
                                    else {
                                        $this->sendMessage($sender, "Usage: /skyblock makeleader <player>");
                                    }
                                }
                                else {
                                    $this->sendMessage($sender, "You must be the island leader to do this!");
                                }
                            }
                            else {
                                $this->sendMessage($sender, "You must be in a island to set a new leader!!");
                            }
                        }
                        break;
                    case "avsaf":
                        $config = $this->plugin->getSkyBlockManager()->getPlayerConfig($sender);
                        if(empty($config->get("island"))) {
                            $this->sendMessage($sender, "§cOnu bırakmak için bir adada olmalısın!");
                        }
                        else {
                            $island = $this->plugin->getIslandManager()->getOnlineIsland($config->get("island"));
                            if($island instanceof Island) {
                                if($island->getOwnerName() == strtolower($sender->getName())) {
                                    $this->sendMessage($sender, "You cannot leave a island if your the owner! Maybe you can try use /skyblock disband");
                                }
                                else {
                                    $this->plugin->getChatHandler()->removePlayerFromChat($sender);
                                    $config->set("island", "");
                                    $config->save();
                                    $island->removeMember(strtolower($sender->getName()));
                                    $this->sendMessage($sender, "You leave the island!!");
                                }
                            }
                            else {
                                $this->sendMessage($sender, "You must be in a island to leave it!!");
                            }
                        }
                        break;
                    case "ortakcikar":
                        $config = $this->plugin->getSkyBlockManager()->getPlayerConfig($sender);
                        if(empty($config->get("island"))) {
                            $this->sendMessage($sender, "Onu çıkarmak için bir adada olmalısın!");
                        }
                        else {
                            $island = $this->plugin->getIslandManager()->getOnlineIsland($config->get("island"));
                            if($island instanceof Island) {
                                if($island->getOwnerName() == strtolower($sender->getName())) {
                                    if(isset($args[1])) {
                                        if(in_array(strtolower($args[1]), $island->getMembers())) {
                                            $island->removeMember(strtolower($args[1]));
                                            $player = $this->plugin->getServer()->getPlayerExact($args[1]);
                                            if($player instanceof Player and $player->isOnline()) {
                                                $this->plugin->getChatHandler()->removePlayerFromChat($player);
                                            }
                                            $this->sendMessage($sender, "§e{$args[1]} §aekibinizden kaldırıldı!");
                                        }
                                        else {
                                            $this->sendMessage($sender, "§e{$args[1]} oyuncusunun bir adası var.");
                                        }
                                    }
                                    else {
                                        $this->sendMessage($sender, "§fKullanım: §6/ada ortakcikar <oyuncu>");
                                    }
                                }
                                else {
                                    $this->sendMessage($sender, "§cBunu yapmak için ada sahibi olmalısın!");
                                }
                            }
                            else {
                                $this->sendMessage($sender, "You must be in a island to leave it!!");
                            }
                        }
                        break;
                    case "tp":
                        if(isset($args[1])) {
                            $island = $this->plugin->getIslandManager()->getIslandByOwner($args[1]);
                            if($island instanceof Island) {
                                if($island->isLocked()) {
                                    $this->sendMessage($sender, "§cBu ada kilitli, ona katılamazsın!");
                                }
                                else {
                                    $sender->teleport(new Position(15, 7, 10, $this->plugin->getServer()->getLevelByName($island->getIdentifier())));
                                    $this->sendMessage($sender, "You joined the island successfully");
                                }
                            }
                            else {
                                $this->sendMessage($sender, "At least one island member must be active if you want see the island!");
                            }
                        }
                        else {
                            $this->sendMessage($sender, "Kullanım: /ada tp <oada-sahip-ismi>");
                        }
                        break;
                    case "sifirla":
                        $config = $this->plugin->getSkyBlockManager()->getPlayerConfig($sender);
                        if(empty($config->get("island"))) {
                            $this->sendMessage($sender, "§cSıfırlamak için bir adada olmalısın!");
                        }
                        else {
                            $island = $this->plugin->getIslandManager()->getOnlineIsland($config->get("island"));
                            if($island instanceof Island) {
                                if($island->getOwnerName() == strtolower($sender->getName())) {
                                    $reset = $this->plugin->getResetHandler()->getResetTimer($sender);
                                    if($reset instanceof Reset) {
                                        $minutes = Utils::printSeconds($reset->getTime());
                                        $this->sendMessage($sender, "§cAdanızı §3{$minutes}§c dakika içinde tekrar sıfırlayabilirsiniz.");
                                    }
                                    else {
                                        foreach($island->getAllMembers() as $member) {
                                            $memberConfig = new Config($this->plugin->getDataFolder() . "users" . DIRECTORY_SEPARATOR . $member . ".json", Config::JSON);
                                            $memberConfig->set("island", "");
                                            $memberConfig->save();
                                        }
                                        $generator = $island->getGenerator();
                                        $this->plugin->getIslandManager()->removeIsland($island);
                                        $this->plugin->getResetHandler()->addResetTimer($sender);
                                        $this->plugin->getSkyBlockManager()->generateIsland($sender, $generator);
                                        $this->sendMessage($sender, "☻1aAda sıfırlandı!");
                                    }
                                }
                                else {
                                    $this->sendMessage($sender, "§Ada'yı sıfırlamak için sahibi olmalısınız!");
                                }
                            }
                            else {
                                $this->sendMessage($sender, "☻1cBunu sıfırlamak için bir adada olmalısınız!");
                            }
                        }
                        break;
                    case "yardim":
                        $commands = [
                            "olustur" => "Ada oluşturur.",
                            "isinlan" => "Adanıza ışınlanır.",
                            "tekmele" => "Adadan oyuncu tekmeler.",
                            "kilit" => "Adanızı Kilitli/Kilitsiz yapar, başkası katılamaz.",
                            "evayarla" => "Ada evini ayarlar.",
                            "ev" => "Ada evinize ışınlanır.",
                            "ortaklar" => "Ortakları görün.",
                            "ortakekle" => "Ortak eklemek için bir davet gönderir.",
                            "ortakcikar" => "Ortak çıkarır.",
                            "tp <sahip-ismi>" => "Sizi başkasının adasına ışınlar.",
                            "kabul/red <gonderen-ismi>" => "Davet varsa kabul/red eder.",
                            "sifirla" => "Adanızı sıfırlar.",
                            "sil" => "Adanızı siler."
                        ];
                        foreach($commands as $command => $description) {
                            $sender->sendMessage("§7» §a/ada §f{$command} §4> §e".$description);
                        }
                        break;
                    case "dsgteh":
                        if($this->plugin->getChatHandler()->isInChat($sender)) {
                            $this->plugin->getChatHandler()->removePlayerFromChat($sender);
                            $this->sendMessage($sender, "You successfully left your team chat!");
                        }
                        else {
                            $config = $this->plugin->getSkyBlockManager()->getPlayerConfig($sender);
                            if(empty($config->get("island"))) {
                                $this->sendMessage($sender, "You must be in a island to use this command!");
                            }
                            else {
                                $island = $this->plugin->getIslandManager()->getOnlineIsland($config->get("island"));
                                if($island instanceof Island) {
                                    $this->plugin->getChatHandler()->addPlayerToChat($sender, $island);
                                    $this->sendMessage($sender, "You joined your team chat room");
                                }
                                else {
                                    $this->sendMessage($sender, "You must be in a island to use this command!!");
                                }
                            }
                        }
                        break;
                    default:
                        $this->sendMessage($sender, "§7»§cKomutu nasıl kullanacağınızı bilmiyorsanız /ada yardim kullanın!");
                        break;
                }
            }
            else {
                $this->sendMessage($sender, "§7»§cKomutu nasıl kullanacağınızı bilmiyorsanız /ada yardim kullanın!");
            }
        }
        else {
            $sender->sendMessage("§7» §cLütfen oyun içinde kullanın!");
        }
    }

}